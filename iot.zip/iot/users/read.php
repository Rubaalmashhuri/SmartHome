<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
// json response array
$response = array("error" => FALSE);
if (isset($_POST['id'])) {
    // receiving the post params
    $id = $_POST['id'];
    // get the user by email and password
    $user = $db->getUserByID($id);
    if ($user != false) {
        // use is found
        $response["error"] = FALSE;
        $response["id"] = $user["id"];
        $response["name"] = $user["name"];
        $response["email"] = $user["email"];
        $response["age"] = $user["age"];
        $response["door"] = $user["door"];
        $response["light"] = $user["light"];
        $response["window"] = $user["window"];
        $response["fridge"] = $user["fridge"];
        $response["heater"] = $user["heater"]; 
        echo json_encode($response);
    } else {
        // user is not found
        $response["error"] = TRUE;
        $response["error_msg"] = "not found. Please try again!";
        echo json_encode($response);
    }
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters uid!";
    echo json_encode($response);
}
?>

