
-- Database: `iot`
--

-- --------------------------------------------------------

--
-- Table structure for table `heater`
--

CREATE TABLE `heater` (
  `id` int(5) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` float NOT NULL,
  `date` datetime NOT NULL
) 