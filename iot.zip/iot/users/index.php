<html>

<title>
    api information

</title>
<body>
<h1>api information</h1>
<p>
<h3>Login:</h3><br/>
<a href="http://35.239.139.245/iot/login.php">http://35.239.139.245/iot/login.php</a><br>
<h4>param:</h4>
email<br>password<br>


<br/>

<h3>response : </h3>

<p>
    {"error":false,"uid":"5e51734b93bf64.06808053","id":4,"user":{"name":"mohed","email":"mohd@gmail.com","created_at":"2020-02-22 20:30:35","updated_at":null}}
</p> <br/>

<p>--------------------------------------------------------------------------------------------------------------</p>
<h3>Registration:</h3><br/>
 <a href="http://35.239.139.245/iot/register.php">http://35.239.139.245/iot/register.php</a>
<h4>param:</h4>
name<br>
email<br>
password<br>
age<br>

<h3>response : </h3>
<p>{"error":false,"uid":"5e5413eaa2f334.22726997","id":5,"user":{"name":"moqq","email":"mossd@gmail.com","age":22,"created_at":"2020-02-24 18:20:26","updated_at":null}}


</p>
<p>--------------------------------------------------------------------------------------------------------------</p>

<h3>Read:</h3><br/>
<a href="http://35.239.139.245/iot/read.php">http://35.239.139.245/iot/read.php</a><br>
<h4>param:</h4>
id<br>

<h4>
{"error":false,"id":4,"user":{"name":"mohed","email":"med@gmil.com","age":22,"door":1,"light":0,"window":8,"fridge":0,"heater":130}}
</h4>
<br/>
<p>--------------------------------------------------------------------------------------------------------------</p>

<h3>update:</h3><br/>
<a href="http://35.239.139.245/iot/update.php">http://35.239.139.245/iot/update.php</a><br>
<h4>param:</h4>
uid<br>
id <br>
door<br>heater
<br>light
<br>window
<br> fridge

<br/>
<h4>

{"error":false,"uid":"5e51734b93bf64.06808053","id":4,"user":{"door":1,"heater":130,"light":0,"window":8,"fridge":0}}


</h4>


<h3>messages:</h3>
wrong enter: <br>
<p>{"error":true,"error_msg":"Login credentials are wrong. Please try again!"}</p>
email already existed :<br>
<p>{"error":true,"error_msg":"User already existed with jghjfgh1111dghfg@kjjk.com"}</p>
<p>"Unknown error occurred in registration!"</p>
<p>"Required parameters (name, email , age or password) is missing!"</p>
<p>"Required parameters email or password is missing!"
</p>

<h2>                                                                   Enjoy! </h2>
</body>
</html>



