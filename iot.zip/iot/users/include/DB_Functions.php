<?php

class DB_Functions
{

    private $conn;

    // constructor
    function __construct()
    {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    // destructor
    function __destruct()
    {

    }

    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($name, $email, $password, $age)
    {
        $uuid = uniqid('', true);
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt

        $stmt = $this->conn->prepare("INSERT INTO users(unique_id, name, email, encrypted_password, age,salt, created_at) VALUES(?,?,?,?,?,?,NOW())");
        $stmt->bind_param("ssssis", $uuid, $name, $email, $encrypted_password, $age, $salt);
        $result = $stmt->execute();
        $stmt->close();

        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;
        } else {
            return false;
        }
    }

    /**
     * Get user by email and password
     */
    public function getUserByEmailAndPassword($email, $password)
    {

        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");

        $stmt->bind_param("s", $email);

        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            // verifying user password
            $salt = $user['salt'];
            $encrypted_password = $user['encrypted_password'];
            $hash = $this->checkhashSSHA($salt, $password);
            // check for password equality
            if ($encrypted_password == $hash) {
                // user authentication details are correct
                return $user;
            }
        } else {
            return NULL;
        }
    }

    /**
     * Check user is existed or not
     */
    public function isUserExisted($email)
    {
        $stmt = $this->conn->prepare("SELECT email from users WHERE email = ?");

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    /**
     * Encrypting password
     * @param password
     * returns salt and encrypted password
     */
    public function hashSSHA($password)
    {

        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }

    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
    public function checkhashSSHA($salt, $password)
    {

        $hash = base64_encode(sha1($password . $salt, true) . $salt);

        return $hash;
    }


    /**
     * Get user by id
     */
    public function getUserByID($id)
    {

        $stmt = $this->conn->prepare
        ("SELECT u.id,u.unique_id,u.name,u.email,u.age,h.id AS h_id, d.status As door,l.status AS light , w.status as window ,f.status as fridge, h.status AS heater ,h.date AS date  FROM users AS u LEFT JOIN door AS d ON u.id=d.user_id LEFT JOIN light AS l ON u.id=l.user_id LEFT JOIN window AS w ON u.id=w.user_id LEFT JOIN fridge AS f ON u.id=f.user_id LEFT JOIN heater AS h ON u.id=h.user_id where u.id =? ORDER BY h.id DESC ,d.id DESC,l.id DESC,w.id DESC,f.id DESC LIMIT 1");
        $stmt->bind_param("s", $id);
        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;

        } else {
            return NULL;
        }
    }

    public function update($window, $door, $heater, $light, $user_id, $fridge)
    {
        $date = date("Y-m-d H:i:s");
        $sql = "
   INSERT INTO `heater` (`user_id`, `status`, `date`) VALUES ('$user_id', '$heater', '$date');
   INSERT INTO `window` (`user_id`, `status`, `date`) VALUES ('$user_id', '$window', '$date');
   INSERT INTO `door` (`user_id`, `status`, `date`) VALUES ('$user_id', '$door', '$date');
   INSERT INTO `fridge` (`user_id`, `status`, `date`) VALUES ('$user_id', '$fridge', '$date');
   INSERT INTO `light` (`user_id`, `status`, `date`) VALUES ('$user_id', '$light', '$date')";
        $connection_mysql = $this->conn;
        if (mysqli_multi_query($connection_mysql, $sql)) {
            do {
                if ($result = mysqli_store_result($connection_mysql)) {
                    while ($row = mysqli_fetch_row($result)) {
                        printf("%s\n", $row[0]);
                    }
                    mysqli_free_result($connection_mysql);
                }
            } while (mysqli_next_result($connection_mysql));
            // check for successful store

            $stmt = $this->conn->prepare("SELECT u.id,u.unique_id,u.name,u.email,u.age,h.id AS h_id, d.status As door,l.status AS light , w.status as window ,f.status as fridge, h.status AS heater ,h.date AS date  FROM users AS u LEFT JOIN door AS d ON u.id=d.user_id LEFT JOIN light AS l ON u.id=l.user_id LEFT JOIN window AS w ON u.id=w.user_id LEFT JOIN fridge AS f ON u.id=f.user_id LEFT JOIN heater AS h ON u.id=h.user_id where u.id =? ORDER BY h.id DESC ,d.id DESC,l.id DESC,w.id DESC,f.id DESC LIMIT 1");
            $stmt->bind_param("s", $user_id);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;

        }
    }


    public function isUserIdExisted($id)
    {
        $stmt = $this->conn->prepare("SELECT id  from users WHERE id  = ?");

        $stmt->bind_param("s", $id);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    public function averageTemp($id, $type, $value)
    {

        if ($type =='t'){

            $stmt = $this->conn->prepare(" SELECT AVG(status) AS avg FROM heater WHERE user_id =? and  CAST(date AS DATE)=CAST(now() AS DATE ) ");
            $stmt->bind_param('s', $id);

        }elseif ($type == 'w') {

            $date = date("Y-m-d ");
            $nameOfDay = date('D', strtotime($date));

            if ($nameOfDay == 'Sun') {

                $stmt = $this->conn->prepare(" SELECT AVG(status) AS avg FROM heater WHERE user_id =? and  CAST(date AS DATE)=? ");
                $stmt->bind_param('ss', $id, $date);

            }elseif ($nameOfDay == 'Mon') {

                $stmt = $this->conn->prepare(" SELECT AVG(status) AS avg FROM heater WHERE user_id=? AND date BETWEEN CAST(? AS DATE)-1 AND CAST(? AS DATE)");
                $stmt->bind_param('sss', $id, $date,$date);

            }elseif ($nameOfDay == 'Tue') {
                $stmt = $this->conn->prepare(" SELECT AVG(status) FROM heater WHERE user_id=? AND date BETWEEN CAST(? AS DATE)-2 AND CAST(? AS DATE)");
                $stmt->bind_param('sss', $id, $date,$date);
            }elseif ($nameOfDay == 'Wed') {
                $stmt = $this->conn->prepare(" SELECT AVG(status) AS avg FROM heater WHERE user_id=? AND date BETWEEN CAST(? AS DATE)-3 AND CAST(? AS DATE)");
                $stmt->bind_param('sss', $id, $date,$date);
            }elseif ($nameOfDay == 'Thu') {
                $stmt = $this->conn->prepare(" SELECT AVG(status) AS avg FROM heater WHERE user_id=? AND date BETWEEN CAST(? AS DATE)-4 AND CAST(? AS DATE)");
                $stmt->bind_param('sss', $id, $date,$date);
            }elseif ($nameOfDay == 'Fri') {
                $stmt = $this->conn->prepare(" SELECT AVG(status) AS avg FROM heater WHERE user_id=? AND date BETWEEN CAST(? AS DATE)-5 AND CAST(? AS DATE)");
                $stmt->bind_param('sss', $id, $date,$date);
            }else {
                return null;
            }

        } elseif ($type == 'm') {
            $stmt = $this->conn->prepare(" SELECT AVG(status) AS avg FROM heater WHERE user_id=? and MONTH( CAST(date AS DATE))= MONTH(CAST(now() AS DATE)) ");
            $stmt->bind_param('s', $id);
        } elseif ($type == 'd') {
                    $stmt = $this->conn->prepare(" SELECT AVG(status) AS avg FROM heater WHERE user_id =? and  CAST(date AS DATE)=? ");
                    $stmt->bind_param('ss', $id,$value);

            } elseif ($type == 'f') {
            $stmt = $this->conn->prepare(" SELECT COUNT(status) AS avg FROM `fridge` WHERE user_id=? AND CAST(date AS DATE)=CAST(now() AS DATE ) AND status=1");
            $stmt->bind_param('s', $id);

        }else {
                return NULL;
            }
          if ($stmt->execute()) {
            $avg = $stmt->get_result()->fetch_assoc();
            $stmt->close();

                 return $avg;
                                }

        }

    }
?>
