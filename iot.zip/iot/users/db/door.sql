
--
-- Database: `iot`
--

-- Table structure for table `door`
--

CREATE TABLE `door` (
  `id` int(5) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `date` date NOT NULL
) 



