<?php



require_once 'include/DB_Functions.php';
$db = new DB_Functions();

// json response array
$response = array("error" => FALSE);

if ( isset($_POST['door'])&& isset($_POST['fridge']) && isset($_POST['heater']) && isset($_POST['light']) && isset($_POST['id'])&&isset($_POST['window'])) {

    // receiving the post params
    
    $door = $_POST['door'];
    $heater = $_POST['heater'];
    $light = $_POST['light'];
    $window = $_POST['window'];
	$user_id = $_POST['id'];
	$fridge = $_POST['fridge'];
    // check if user is already existed with the same email
    if ($db->isUserIdExisted($user_id)) {
        // create a new user
        $user = $db->update($window,$door,$heater,$light,$user_id,$fridge);
        if ($user) {
            // user stored successfully
            $response["error"] = FALSE;
			$response["id"] = $user["id"];
            $response["door"] = $user["door"];
            $response["heater"] = $user["heater"];
            $response["light"] = $user["light"];
            $response["window"] = $user["window"];
		    $response["fridge"] = $user["fridge"];
            echo json_encode($response);
        } else {
            // user failed to store
             $response["error"] = TRUE;
            $response["error_msg"] = "Unknown error occurred in update!"; 
            echo json_encode($response);
        }
    } else {

        $response["error"] = TRUE;
        $response["error_msg"] = "User notfound " ;
        echo json_encode($response);
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (uid,door,heater,light,window)";
    echo json_encode($response);
}
?>
