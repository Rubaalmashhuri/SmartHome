<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
// json response array
$response = array("error" => FALSE);
if (!isset($_POST['value']))
{
    $_POST['value']=NULL;
}
if (isset($_POST['id']) && isset($_POST['type']) && isset($_POST['value'])) {
    // receiving the post params
    $id = $_POST['id'];
    $type = $_POST['type'];
    $value=$_POST['value'];

    // get the user by email and password
    $user = $db->getUserByID($id);
    $avg = $db->averageTemp($id,$type,$value);
    if ($user != false) {
        // use is found

        $response["error"] = FALSE;
        $response["value"] = $avg['avg'] ;

        echo json_encode($response);
    } else {
        // user is not found
        $response["error"] = TRUE;
        $response["error_msg"] = "not found. Please try again!";
        echo json_encode($response);
    }
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters !";
    echo json_encode($response);
}
?>

